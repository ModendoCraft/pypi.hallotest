# hallo_test

Eine kleine Python-Library für Begrüßungen.

## Features

- `hallo()` – klassische Begrüßung
- `gruesse()` – zufällige Begrüßung aus mehreren Varianten

## Installation

pip install hallo_test